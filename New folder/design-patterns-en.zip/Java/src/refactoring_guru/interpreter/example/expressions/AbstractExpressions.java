package refactoring_guru.interpreter.example.expressions;

public abstract class AbstractExpressions {
    public abstract boolean interpret(Context context) throws Exception;
}

package main

type pizza interface {
	getPrice() int
}
